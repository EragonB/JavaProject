package contract;

// TODO: Auto-generated Javadoc
/**
 * The Enum State.
 */
public enum State {

/** The Life. */
Life, 
 /** The Dead. */
 Dead, 
 /** The Finish. */
 Finish
}
