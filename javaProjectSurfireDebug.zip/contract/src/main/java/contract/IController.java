package contract;

// TODO: Auto-generated Javadoc
/**
 * The Interface IController.
 */
public interface IController {
	
	/**
	 * Move.
	 *
	 * @param i the i
	 */
	public void move(int i);
}
