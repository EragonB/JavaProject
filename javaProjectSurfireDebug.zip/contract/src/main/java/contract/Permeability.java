/**
 * 
 */
package contract;

// TODO: Auto-generated Javadoc
/**
 * The Enum Permeability.
 *
 * @author Bryan
 */
public enum Permeability {

/** The Blocking. */
Blocking, 
 /** The Creusable. */
 Creusable, 
 /** The Passable. */
 Passable, 
 /** The Push. */
 Push,
 
 /** The Enemy. */
 Enemy,
 
 /** The Recover. */
 Recover, 
 
 /** The Door. */
 Door
}
