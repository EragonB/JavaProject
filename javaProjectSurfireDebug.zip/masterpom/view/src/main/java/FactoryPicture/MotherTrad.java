package FactoryPicture;

import java.awt.Image;

// TODO: Auto-generated Javadoc
/**
 * The Class MotherTrad.
 */
public abstract class MotherTrad {
	
	/**
	 * Gets the picture.
	 *
	 * @return the picture
	 */
	public Image getPicture() {
		return null;	
	}

}
