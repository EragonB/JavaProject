# JPU-BlankProject

Start-up base for Exia-Cesi 1st year Jave / POO / UML project
