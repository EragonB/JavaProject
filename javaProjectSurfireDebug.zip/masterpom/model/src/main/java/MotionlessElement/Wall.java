package MotionlessElement;

import contract.Permeability;

// TODO: Auto-generated Javadoc
/**
 * The Class Wall.
 */
public class Wall extends MotionlessElement{
	
	/**
	 * Instantiates a new wall.
	 */
	public Wall()
	{
		super(Permeability.Blocking, 'X');
	}

}
