package MotionlessElement;

import contract.Permeability;

// TODO: Auto-generated Javadoc
/**
 * The Class Door.
 */
public class Door extends MotionlessElement{

	/**
	 * Instantiates a new door.
	 */
	public Door() {
		super(Permeability.Door, 'A');
		// TODO Auto-generated constructor stub
	}

}
