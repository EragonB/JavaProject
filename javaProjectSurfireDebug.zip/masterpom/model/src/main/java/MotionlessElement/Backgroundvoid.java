package MotionlessElement;

import contract.Permeability;

// TODO: Auto-generated Javadoc
/**
 * The Class Backgroundvoid.
 */
public class Backgroundvoid extends MotionlessElement{

	/**
	 * Instantiates a new backgroundvoid.
	 */
	public Backgroundvoid() {
		super(Permeability.Passable, ' ');
		
	}



}
