package MotionlessElement;

import contract.Permeability;

// TODO: Auto-generated Javadoc
/**
 * The Class Dirt.
 */
public class Dirt extends MotionlessElement{

	/**
	 * Instantiates a new dirt.
	 */
	public Dirt() {
		super(Permeability.Creusable, 'T');
		// TODO Auto-generated constructor stub
	}

}
